#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024

void display_menu();

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[1]);
    int sock;
    struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE] = {0};

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation error");
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    // Convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address/ Address not supported");
        return -1;
    }

    // Connect to server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        return -1;
    }

    printf("Connected to server at 127.0.0.1:%d\n", port);

    while (1) {
        display_menu();
        int choice;
        char city[50], weather[100];

        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // Clear newline

        switch (choice) {
            case 1: // GET weather
                printf("Enter city name: ");
                fgets(city, sizeof(city), stdin);
                city[strcspn(city, "\n")] = 0; // Remove newline

                snprintf(buffer, BUFFER_SIZE, "GET %s", city);
                send(sock, buffer, strlen(buffer), 0);

                memset(buffer, 0, BUFFER_SIZE);
                read(sock, buffer, BUFFER_SIZE);
                printf("%s\n", buffer);
                break;

            case 2: // ADD weather
                printf("Enter city name: ");
                fgets(city, sizeof(city), stdin);
                city[strcspn(city, "\n")] = 0; // Remove newline

                printf("Enter weather information: ");
                fgets(weather, sizeof(weather), stdin);
                weather[strcspn(weather, "\n")] = 0; // Remove newline

                snprintf(buffer, BUFFER_SIZE, "ADD %s %s", city, weather);
                send(sock, buffer, strlen(buffer), 0);

                memset(buffer, 0, BUFFER_SIZE);
                read(sock, buffer, BUFFER_SIZE);
                printf("%s\n", buffer);
                break;

            case 3: // Exit
                printf("Exiting...\n");
                close(sock);
                return 0;

            default:
                printf("Invalid choice. Try again.\n");
        }
    }

    return 0;
}

void display_menu() {
    printf("\n--- Weather Information Service ---\n");
    printf("1. Get weather information\n");
    printf("2. Add weather information\n");
    printf("3. Exit\n");
}
