#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE 1024

void handle_client(int client_sock);

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return -1;
    }

    int port = atoi(argv[1]);
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    // Create socket
    if ((server_sock = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    // Bind the socket
    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        return -1;
    }

    // Listen for connections
    if (listen(server_sock, 3) < 0) {
        perror("Listen failed");
        close(server_sock);
        return -1;
    }

    printf("Server is running on port %d...\n", port);

    while (1) {
        // Accept client connection
        if ((client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &addr_len)) < 0) {
            perror("Accept failed");
            close(server_sock);
            return -1;
        }

        printf("Client connected.\n");
        handle_client(client_sock);
        close(client_sock);
        printf("Client disconnected.\n");
    }

    close(server_sock);
    return 0;
}

void handle_client(int client_sock) {
    char buffer[BUFFER_SIZE] = {0};

    while (1) {
        int valread = read(client_sock, buffer, BUFFER_SIZE);
        if (valread <= 0) break;

        printf("Received: %s\n", buffer);

        if (strncmp(buffer, "GET", 3) == 0) {
            // Handle GET request
            snprintf(buffer, BUFFER_SIZE, "Weather info for city: %s", buffer + 4);
        } else if (strncmp(buffer, "ADD", 3) == 0) {
            // Handle ADD request
            snprintf(buffer, BUFFER_SIZE, "Weather info added for city: %s", buffer + 4);
        } else {
            snprintf(buffer, BUFFER_SIZE, "Invalid command");
        }

        send(client_sock, buffer, strlen(buffer), 0);
        memset(buffer, 0, BUFFER_SIZE);
    }
}
